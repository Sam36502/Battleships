#!/bin/bash
java -jar ./Battleships.jar