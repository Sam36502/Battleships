# Battleships
A simple implementation of the battleships boardgame. To be run in the console.

## Usage
To play the game, just download the latest version under releases, and make sure you have
java installed. Once you have the latest version just run the command line script.
 * Battleships.sh on Linux
 * Battleships.bat on Windows
 Once the game is running, just follow the on-screen instructions, and have fun!
 
