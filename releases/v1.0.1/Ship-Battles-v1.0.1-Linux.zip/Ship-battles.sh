#!/bin/bash
java -jar Ship-battles.jar